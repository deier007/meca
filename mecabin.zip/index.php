<?php include 'header.php'; ?>
<?php

if (!isset($_SESSION['Admin-name'])) {
  header("location: login.php");
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Users</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
  <link rel="icon" type="image/png" href="images/favicon.png">
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: [
          'copyHtml5',
          'excelHtml5',
          'csvHtml5',
          'pdfHtml5'
        ]
      });
    });
  </script>
  <!-- includes -->
  <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script>
    $(window).on("load resize ", function() {
      var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
      $('.tbl-header').css({
        'padding-right': scrollWidth
      });
    }).resize();
  </script>
</head>

<body>

  <main>
    <section>
      <div class="row">
        <div class="col"> </div>
      </div>
      <div class="row">
        <div class="col"> </div>
      </div>

      <h1 class="slideInDown animated">Here are all the Products</h1>
      <!--User table-->

      <div class="table-responsive slideInRight animated" style="max-height: 400px;">
        <table id="example" class="display" style="width:100%">
          <thead class="table-primary">
            <tr>
            <th>ID </th>
            <th>Barcode</th>
              <th>Name</th>
              <th>Weight Kg</th>
            

            </tr>
          </thead>
          <tbody class="table-secondary">
            <?php
            //Connect to database
            require 'connectDB.php';
            $sql = "SELECT * FROM product ";
            $result = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($result, $sql)) {
              echo '<p class="error">SQL Error</p>';
            } else {
              mysqli_stmt_execute($result);
              $resultl = mysqli_stmt_get_result($result);
              if (mysqli_num_rows($resultl) > 0) {
                while ($row = mysqli_fetch_assoc($resultl)) {
            ?>
                  <TR>
                    <TD><?php echo $row['ID'];        ?></TD>
                     
                    <TD><?php echo $row['barcode']; ?></TD>
                    <TD><?php echo $row['name_product']; ?></TD>
                    <TD><?php echo $row['weight']; ?></TD>
                  </TR>
            <?php
                }
              }
            }
            ?>
          </tbody>

          <tfoot>
            <tr>
            <th>ID </th>
            <th>Barcode</th>
              <th>Name</th>
              <th>Weight Kg</th>
           
            </tr>
          </tfoot>
        </table>
      </div>
      <footer class="page-footer font-small blue pt-8">

      </footer>
      <!-- Footer -->
    </section>
  </main>
</body>

</html>