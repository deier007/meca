<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "tutcmecatk_database";		//put your phpmyadmin username.(default is "root")
    $password = "Nam23456nam";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "tutcmecatk_manager";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>